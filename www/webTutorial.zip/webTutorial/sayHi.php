<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Hello User</title>
	</head>
	<body>
		<h1>Hello User</h1>
		Hello <?php echo($_REQUEST["usersName"]); ?>, how are you doing?
	</body>
</html>
