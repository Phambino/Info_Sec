<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Hello User</title>
	</head>
	<body>
		<h1>Hello User</h1>
		Hello 
		<?php echo($_REQUEST["usersName1"]); ?>
		and 
		<?php echo($_REQUEST["usersName2"]); ?>
		, how are you both doing?
	</body>
</html>
